package project2;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Basketball")
public class Basketball extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String Name=request.getParameter("name");
		String Age=request.getParameter("age");
		String Sex=request.getParameter("sex");
		String Mobile=request.getParameter("mobile");
		String Staying=request.getParameter("staying");
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/nitish","root","Nitish123#");
			Statement stmt=con.createStatement();
			stmt.executeUpdate("insert into cricket values('"+Name+"','"+Age+"','"+Sex+"','"+Mobile+"','"+Staying+"')");
		
				out.println("data inserted.....");
            }
		catch(Exception e2)
		{
			System.out.println(e2);
		}
		
			
		out.close();
		
	}
}
