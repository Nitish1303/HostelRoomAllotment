package project2;

	import java.io.IOException;
	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;


	@WebServlet("/LoginController")
	public class LoginController extends HttpServlet {

	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        String un = request.getParameter("uname");
	        String pw = request.getParameter("psw");

	        if (un.equals("admin") && pw.equals("admin")) {
	            response.sendRedirect("Warden.html");
	            return;}
	            else if(un.equals("nitish") && pw.equals("1234")) 
	            {
	            	response.sendRedirect("Warden1.html");
		            return;
	            }
	         else {
	            response.sendRedirect("index.html");
	            return;
	        }
	    }

	}
